
public class AplicacaoJava {

	public static void main(String args[]) {
		
		new CloudToMongo().beginConnection();
		new MongoToSQL().beginConnection();
		
		//new MongoToSQL().inserirAlerta("400", "hum", "CURRENT_TIME", "Alerta de Humidade Teste", "0", "Extra");
		
	}
	
}
