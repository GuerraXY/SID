import java.io.FileInputStream;
import java.util.Properties;

import javax.swing.JOptionPane;

import org.bson.Document;
import org.bson.conversions.Bson;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

public class MongoToSQL {

    private String sql_database = "sid2020";
    private String sql_table_migracoes = "Medi��esSensores";
    private String sql_table_alertas = "Alerta";
    
    static private Connection SQLconnection;
    
    static private CloudToMongo cloudToMongo;
    
    public void beginConnection() {
    	
    	try {
            Properties p = new Properties();
            p.load(new FileInputStream("MongoToSQL.ini"));
        } catch (Exception e) {

            System.out.println("Error reading CloudToMongo.ini file " + e);
            JOptionPane.showMessageDialog(null, "The CloudToMongo.inifile wasn't found.", "CloudToMongo", JOptionPane.ERROR_MESSAGE);
        }
        
    	cloudToMongo = new CloudToMongo();
        SQLconnection = connectSQL();
        migrateAllFromMongoToSQL();//Migra todas as linhas que ainda n�o foram migradas
    	
    }
    
    public void declararComoMigrado(DBObject linhaMigrada) { //Muda a Flag Migrada para 1  	
    	
    	BasicDBObject newDocument = new BasicDBObject();
		newDocument.append("$set", new BasicDBObject().append("FlagMigrado", 1));

		CloudToMongo.mongocol.update(linhaMigrada, newDocument);
    	
    }
    
    public Connection connectSQL() {
    	
    	String serverName = "localhost";

		String username = "root";
		String password = "abcd1234";
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/" + sql_database + "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC"
					, "root", "abcd1234");
		
			return connection;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
    	
    }
    
    public String obterValorDoObjeto(DBObject objeto, String valorAObter) {
    	
    	String valorMovimento = null;
    	try{
    		valorMovimento = objeto.get(valorAObter).toString();
    	} catch(Exception e) {
    	}
    	
    	return valorMovimento;
    	
    }
    
    public void inserirAlerta(String valorMedicao, String tipoSensor, String dataHoraMedicao, String descricao, String controlo, String extra) {
    	
    	String limite = "0"; //Mudar de acordo com o que vai estar no .ini   	
    	
    	try {
			Statement statement = SQLconnection.createStatement();
			
			statement.executeUpdate("INSERT INTO " + sql_table_alertas + " (ValorMedicao, TipoSensor, DataHoraMedicao, Limite, Descricao, Controlo, Extra) "
					+ "VALUES (" + valorMedicao + ", '" + tipoSensor + "', " + dataHoraMedicao + ", " + limite + ", '" + descricao + "', " + controlo + ", '" + extra + "')");
		
    	} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public void migrateToSQL(DBObject objetoAMigrar){
    	
    	String hora = obterValorDoObjeto(objetoAMigrar, "Hora");
    	String data = obterValorDoObjeto(objetoAMigrar, "Data");
    	String valorTemperatura = obterValorDoObjeto(objetoAMigrar, "Temperatura");
    	String valorHumidade = obterValorDoObjeto(objetoAMigrar, "Humidade");
    	String valorLuminosidade = obterValorDoObjeto(objetoAMigrar, "Luminosidade");
    	String valorMovimento = obterValorDoObjeto(objetoAMigrar, "Movimento");
    	
    	String[] dataVetor = data.split("/");
    	String dataEHora = dataVetor[2] + "-" + dataVetor[1] + "-" + dataVetor[0] + " " + hora;
    	
    	//METER FILTROS AQUI
    	//NUNCA SE PODE METER FAZER obterValorDoObjeto(objetoAMigrar, "Hora"); e dar null!
    	
    	try {
			Statement statement = SQLconnection.createStatement();
			//Inserir todos os tipos diferentes de medi��o
			statement.executeUpdate("INSERT INTO " + sql_table_migracoes + " (ValorMedi��o, TipoSensor, DataHoraMedi��o) VALUES ('" + valorTemperatura + "', 'tmp', '" + dataEHora + "')");
			statement.executeUpdate("INSERT INTO " + sql_table_migracoes + " (ValorMedi��o, TipoSensor, DataHoraMedi��o) VALUES ('" + valorHumidade + "', 'hum', '" + dataEHora + "')");
			statement.executeUpdate("INSERT INTO " + sql_table_migracoes + " (ValorMedi��o, TipoSensor, DataHoraMedi��o) VALUES ('" + valorLuminosidade + "', 'lum', '" + dataEHora + "')");
			statement.executeUpdate("INSERT INTO " + sql_table_migracoes + " (ValorMedi��o, TipoSensor, DataHoraMedi��o) VALUES (NULL, 'mov','" + dataEHora + "')");
			
			declararComoMigrado(objetoAMigrar);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    
    public void migrateAllFromMongoToSQL() {
    	
    	BasicDBObject searchQuery = new BasicDBObject();
    	searchQuery.put("FlagMigrado", "0");
    	DBCursor cursor = cloudToMongo.mongocol.find(searchQuery);
        
        //Mandar linha no cursor para o Java
        while (cursor.hasNext()) {
    		
        	migrateToSQL(cursor.next());
        	  
        }
        
    }
	
}
