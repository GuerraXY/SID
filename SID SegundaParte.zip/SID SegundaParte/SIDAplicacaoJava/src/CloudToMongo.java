import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import com.mongodb.*;
import com.mongodb.util.JSON;

import java.util.*;
import java.util.Vector;
import java.io.File;
import java.io.*;
import javax.swing.*;


public class CloudToMongo implements MqttCallback {
    MqttClient mqttclient;
    static MongoClient mongoClient;
    static DB db;
    static DBCollection mongocol;
    static String cloud_server = new String();
    static String cloud_topic = new String();
    static String mongo_host = new String();
    static String mongo_database = new String();
    static String mongo_collection = new String();
    
    private CloudToMongo cloudToMongo;
    static MongoToSQL mongoToSQL;

    //mudar topico para funcionar para o SimulateSensor
    
    
    public static void beginConnection() {

        try {
            Properties p = new Properties();
            p.load(new FileInputStream("cloudToMongo.ini"));
            cloud_server = p.getProperty("cloud_server");
            cloud_topic = p.getProperty("cloud_topic");
            mongo_host = p.getProperty("mongo_host");
            mongo_database = p.getProperty("mongo_database");
            mongo_collection = p.getProperty("mongo_collection");
        } catch (Exception e) {

            System.out.println("Error reading CloudToMongo.ini file " + e);
            JOptionPane.showMessageDialog(null, "The CloudToMongo.inifile wasn't found.", "CloudToMongo", JOptionPane.ERROR_MESSAGE);
        }
        
        //Estabelecer conex�es
        new CloudToMongo().connectCloud();
        new CloudToMongo().connectMongo();
        mongoToSQL = new MongoToSQL();
    }

    public void connectCloud() {
		int i;
        try {
			i = new Random().nextInt(100000);
            mqttclient = new MqttClient(cloud_server, "CloudToMongo_"+String.valueOf(i)+"_"+cloud_topic);
            mqttclient.connect();
            mqttclient.setCallback(this);
            mqttclient.subscribe(cloud_topic);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void connectMongo() {
		mongoClient = new MongoClient(new MongoClientURI(mongo_host));
		db = mongoClient.getDB(mongo_database);
        mongocol = db.getCollection(mongo_collection);
    }


    @Override
    public void messageArrived(String topic, MqttMessage c) 
            throws Exception {
		
        try {
        	
                DBObject document_json;

                document_json = (DBObject) JSON.parse(clean(c.toString()));
                
                //Mudar estrutura do documento a inserir
                BasicDBObject documentoAInserir = new BasicDBObject();
                documentoAInserir.put("Temperatura", document_json.get("tmp"));
                documentoAInserir.put("Humidade", document_json.get("hum"));
                documentoAInserir.put("Data", document_json.get("dat"));
                documentoAInserir.put("Hora", document_json.get("tim"));
                documentoAInserir.put("Luminosidade", document_json.get("cell"));
                documentoAInserir.put("Movimento", document_json.get("mov"));
                documentoAInserir.put("FlagMigrado", 0);
                

                System.out.println(documentoAInserir.toString());
               
                mongocol.insert(documentoAInserir);   
                mongoToSQL.migrateToSQL(documentoAInserir);
                
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void connectionLost(Throwable cause) {
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {
    }
  
    public String clean(String message) {
		return (message.replaceAll("\"\"", "\","));
        
    }	

}