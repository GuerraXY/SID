CREATE DATABASE IF NOT EXISTS sid2020;

USE sid2020;

CREATE TABLE if not exists Utilizador (
	Email varchar(100) NOT NULL PRIMARY KEY,
	Nome varchar(200) NOT NULL,
	Tipo varchar(3) NOT NULL
);

CREATE TABLE if not exists RondaExtra (
	EmailUtilizador varchar(100),
	DataHoraInicio timestamp,
    DataHoraFim timestamp,
	CONSTRAINT PK_RondaExtra PRIMARY KEY (EmailUtilizador,DataHoraInicio),
	FOREIGN KEY (EmailUtilizador)
		REFERENCES Utilizador (Email)
		ON UPDATE CASCADE
);

CREATE TABLE if not exists RondaPlaneada (
	EmailUtilizador varchar(100),
	DiaSemana varchar(20),
	HoraRondaInicio time,
    HoraRondaFim time,
	CONSTRAINT PK_RondaPlaneada PRIMARY KEY (EmailUtilizador,DiaSemana,HoraRondaInicio),
	FOREIGN KEY (EmailUtilizador)
		REFERENCES Utilizador (Email)
		ON UPDATE CASCADE
		ON DELETE CASCADE
);

CREATE TABLE if not exists Sistema (
	LimiteTemperatura decimal(6,2),
	LimiteHumidade decimal(6,2),
	LimiteLuminosidade decimal(6,2)
);

CREATE TABLE if not exists MediçõesSensores (
	IDMedição int PRIMARY KEY AUTO_INCREMENT,
	ValorMedição decimal(6,2),
	TipoSensor varchar(3),
	DataHoraMedição timestamp
);

CREATE TABLE if not exists Alerta (
	ID int PRIMARY KEY AUTO_INCREMENT,
	ValorMedicao decimal(6,2),
	TipoSensor varchar(3),
	DataHoraMedicao timestamp,
    Limite decimal(6,2),
    Descricao varchar(1000),
    Controlo boolean,
    Extra varchar(50)
);

	